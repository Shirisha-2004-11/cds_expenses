import 'package:flutter/material.dart';
import 'dart:math' as math;

// ─── Data models ──────────────────────────────────────────────────────────────
class _BudgetCategoryData {
  final String label;
  final Color color;
  final double amount;
  const _BudgetCategoryData(this.label, this.color, this.amount);
}

class _BudgetExpenseItem {
  final String label;
  final IconData icon;
  final Color iconBg;
  final double amount;
  final double percent;
  final bool isUp; // true = more than last month
  final double diffAmount;
  const _BudgetExpenseItem({
    required this.label,
    required this.icon,
    required this.iconBg,
    required this.amount,
    required this.percent,
    required this.isUp,
    required this.diffAmount,
  });
}

// ─── Main screen ──────────────────────────────────────────────────────────────
class BudgetOverviewScreen extends StatelessWidget {
  const BudgetOverviewScreen({super.key});

  static const _categories = [
    _BudgetCategoryData('Food',     Color(0xFFF4C26A), 4250),
    _BudgetCategoryData('Travel',   Color(0xFF9EC8F5), 2540),
    _BudgetCategoryData('Supplies', Color(0xFFF4956A), 4100),
    _BudgetCategoryData('Bills',    Color(0xFFB89EF5), 3790),
    _BudgetCategoryData('Others',   Color(0xFFB5D99C), 1560),
  ];

  static const _expenses = [
    _BudgetExpenseItem(
      label: 'Food',
      icon: Icons.lunch_dining_rounded,
      iconBg: Color(0xFFFFF0D9),
      amount: 4250,
      percent: 11,
      isUp: true,
      diffAmount: 490,
    ),
    _BudgetExpenseItem(
      label: 'Supplies',
      icon: Icons.shopping_cart_rounded,
      iconBg: Color(0xFFFFE8D9),
      amount: 4100,
      percent: 9,
      isUp: false,
      diffAmount: 340,
    ),
    _BudgetExpenseItem(
      label: 'Bills',
      icon: Icons.receipt_long_rounded,
      iconBg: Color(0xFFEDE4FF),
      amount: 3790,
      percent: 18,
      isUp: true,
      diffAmount: 560,
    ),
    _BudgetExpenseItem(
      label: 'Travel',
      icon: Icons.directions_car_rounded,
      iconBg: Color(0xFFDEEEFF),
      amount: 2540,
      percent: 15,
      isUp: false,
      diffAmount: 280,
    ),
    _BudgetExpenseItem(
      label: 'Health',
      icon: Icons.local_pharmacy_rounded,
      iconBg: Color(0xFFE4F5DA),
      amount: 2540,
      percent: 15,
      isUp: false,
      diffAmount: 300,
    ),
  ];

  double get _total => _categories.fold(0, (s, c) => s + c.amount);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          children: [
            _BudgetHeader(),
            const SizedBox(height: 20),
            _BudgetSummaryCard(categories: _categories, total: _total),
            const SizedBox(height: 20),
            _BudgetTopExpensesCard(expenses: _expenses, total: _total),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

// ─── Header ───────────────────────────────────────────────────────────────────
class _BudgetHeader extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.maybePop(context),
          child: const Icon(Icons.chevron_left, size: 28, color: Colors.black87),
        ),
        const Expanded(
          child: Text(
            'March 2026',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.black87,
            ),
          ),
        ),
        const SizedBox(width: 28),
      ],
    );
  }
}

// ─── Summary card ─────────────────────────────────────────────────────────────
class _BudgetSummaryCard extends StatelessWidget {
  final List<_BudgetCategoryData> categories;
  final double total;
  const _BudgetSummaryCard({required this.categories, required this.total});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _BudgetAmountLabel(title: 'Previous month', amount: 11480),
              const SizedBox(width: 40),
              _BudgetAmountLabel(title: 'Total expenses', amount: 14480, isBold: true),
            ],
          ),
          const SizedBox(height: 24),
          Row(
            children: [
              SizedBox(
                width: 130,
                height: 130,
                child: CustomPaint(
                  painter: _BudgetDonutPainter(categories: categories, total: total),
                ),
              ),
              const SizedBox(width: 20),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: categories
                      .map((c) => _BudgetLegendRow(category: c))
                      .toList(),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _BudgetAmountLabel extends StatelessWidget {
  final String title;
  final double amount;
  final bool isBold;
  const _BudgetAmountLabel({
    required this.title,
    required this.amount,
    this.isBold = false,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '₹ ${_budgetFmt(amount)}',
          style: TextStyle(
            fontSize: isBold ? 22 : 20,
            fontWeight: isBold ? FontWeight.w700 : FontWeight.w600,
            color: Colors.black87,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          title,
          style: const TextStyle(fontSize: 12, color: Colors.black45),
        ),
      ],
    );
  }
}

class _BudgetLegendRow extends StatelessWidget {
  final _BudgetCategoryData category;
  const _BudgetLegendRow({required this.category});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(
              color: category.color,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              category.label,
              style: const TextStyle(fontSize: 13, color: Colors.black54),
            ),
          ),
          Text(
            '₹ ${_budgetFmt(category.amount)}',
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Donut chart painter ──────────────────────────────────────────────────────
class _BudgetDonutPainter extends CustomPainter {
  final List<_BudgetCategoryData> categories;
  final double total;
  const _BudgetDonutPainter({required this.categories, required this.total});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final outerR = math.min(cx, cy);
    final innerR = outerR * 0.56;
    const gap = 2.0;

    double startAngle = -math.pi / 2;

    for (final cat in categories) {
      final sweep = (cat.amount / total) * 2 * math.pi;
      final gapRad = gap * math.pi / 180;

      final paint = Paint()
        ..color = cat.color
        ..style = PaintingStyle.stroke
        ..strokeWidth = outerR - innerR
        ..strokeCap = StrokeCap.butt;

      canvas.drawArc(
        Rect.fromCircle(
          center: Offset(cx, cy),
          radius: innerR + (outerR - innerR) / 2,
        ),
        startAngle + gapRad / 2,
        sweep - gapRad,
        false,
        paint,
      );
      startAngle += sweep;
    }
  }

  @override
  bool shouldRepaint(_BudgetDonutPainter old) => false;
}

// ─── Top expenses card ────────────────────────────────────────────────────────
class _BudgetTopExpensesCard extends StatelessWidget {
  final List<_BudgetExpenseItem> expenses;
  final double total;
  const _BudgetTopExpensesCard({required this.expenses, required this.total});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Top expenses',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 16),
          ...expenses.map((e) => _BudgetExpenseRow(item: e, total: total)),
        ],
      ),
    );
  }
}

class _BudgetExpenseRow extends StatelessWidget {
  final _BudgetExpenseItem item;
  final double total;
  const _BudgetExpenseRow({required this.item, required this.total});

  @override
  Widget build(BuildContext context) {
    final barFraction = item.amount / total;
    final diffText = item.isUp
        ? '₹${_budgetFmt(item.diffAmount)} more this month'
        : '₹${_budgetFmt(item.diffAmount)} less this month';

    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: item.iconBg,
              shape: BoxShape.circle,
            ),
            child: Icon(item.icon, size: 20, color: _iconColor(item.iconBg)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      item.label,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: Colors.black87,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      '₹ ${_budgetFmt(item.amount)}',
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(width: 6),
                    _BudgetPercentBadge(percent: item.percent, isUp: item.isUp),
                  ],
                ),
                const SizedBox(height: 6),
                LayoutBuilder(builder: (context, constraints) {
                  return Stack(
                    children: [
                      Container(
                        height: 6,
                        decoration: BoxDecoration(
                          color: const Color(0xFFF0F0F0),
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                      Container(
                        height: 6,
                        width: constraints.maxWidth * barFraction,
                        decoration: BoxDecoration(
                          color: _barColor(item.iconBg),
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                    ],
                  );
                }),
                const SizedBox(height: 4),
                Text(
                  diffText,
                  style: const TextStyle(fontSize: 11, color: Colors.black38),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _iconColor(Color bg) {
    final hsl = HSLColor.fromColor(bg);
    return hsl.withLightness((hsl.lightness - 0.35).clamp(0.0, 1.0)).toColor();
  }

  Color _barColor(Color bg) {
    final hsl = HSLColor.fromColor(bg);
    return hsl.withLightness((hsl.lightness - 0.15).clamp(0.0, 1.0)).toColor();
  }
}

class _BudgetPercentBadge extends StatelessWidget {
  final double percent;
  final bool isUp;
  const _BudgetPercentBadge({required this.percent, required this.isUp});

  @override
  Widget build(BuildContext context) {
    final color = isUp ? const Color(0xFFE05C5C) : const Color(0xFF4CAF50);
    final icon = isUp ? Icons.north_east_rounded : Icons.south_east_rounded;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          '${percent.toInt()}%',
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: color,
          ),
        ),
        Icon(icon, size: 13, color: color),
      ],
    );
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
String _budgetFmt(double v) {
  final i = v.toInt();
  if (i >= 1000) {
    return '${(i / 1000).toStringAsFixed(i % 1000 == 0 ? 0 : 1)}k';
  }
  return i.toString();
}
