import 'package:cds_expenses/screens/auth/welcome_screen.dart';
import 'package:flutter/material.dart';
import 'package:cds_expenses/Dashboard_path/Dashboard.dart';
import 'package:cds_expenses/theme/app_theme.dart';
import 'package:cds_expenses/Dashboard_path/InsightsCards.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'services/auth_state.dart';

// ✅ FIX: main() is now async so we can re-hydrate AuthState before runApp.
//         This ensures the JWT token is available in memory immediately when
//         the app starts (e.g. after a page refresh or cold launch on web),
//         so DashboardService.fetchAll() finds the token without any race condition.
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Re-hydrate in-memory token store from SharedPreferences on cold start.
  // On Flutter Web, SharedPreferences is backed by localStorage, so the token
  // survives page refreshes. We load it here once, before the widget tree
  // builds, so ApiConfig.authHeaders always finds AuthState.token non-empty.
  final prefs = await SharedPreferences.getInstance();
  final savedToken = prefs.getString('auth_token');
  final savedName  = prefs.getString('user_name');
  if (savedToken != null && savedToken.isNotEmpty) {
    AuthState.setToken(savedToken, userName: savedName);
  }

  runApp(const CDSExpensesApp());
}

class CDSExpensesApp extends StatelessWidget {
  const CDSExpensesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CDS Expenses',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      home: const WelcomeScreen(),
      routes: {
        '/dashboard': (context) => const DashboardScreen(),
        '/insights':  (context) => const SpendingInsightsScreen(),
      },
    );
  }
}