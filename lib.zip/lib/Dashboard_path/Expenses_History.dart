import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import '../constants/api_config.dart';

// ─── Data Model ───────────────────────────────────────────────────────────────

class ExpenseItem {
  final String category;   // e.g. "Food", "Travel"
  final String merchant;   // e.g. "Udipi Hotel", "Swiggy"
  final String date;
  final String note;
  final int amount;
  final Color iconBg;
  final Color iconColor;
  final IconData icon;

  const ExpenseItem({
    required this.category,
    required this.merchant,
    required this.date,
    required this.note,
    required this.amount,
    required this.iconBg,
    required this.iconColor,
    required this.icon,
  });

  // ── Merchant → correct category override map ──────────────────────────────
  // If the backend stores the wrong category for a known merchant/brand,
  // this table wins. Keys are lowercase substrings of the merchant name.
  static const Map<String, String> _merchantCategoryOverrides = {
    // Medical / Pharmacy
    'apollo'       : 'Medical',
    'medplus'      : 'Medical',
    'netmeds'      : 'Medical',
    'pharmeasy'    : 'Medical',
    '1mg'          : 'Medical',
    'practo'       : 'Medical',
    'fortis'       : 'Medical',
    'manipal'      : 'Medical',
    'narayana'     : 'Medical',
    'max hospital' : 'Medical',
    'aiims'        : 'Medical',
    'cipla'        : 'Medical',
    'dr.'          : 'Medical',
    'clinic'       : 'Medical',
    'hospital'     : 'Medical',
    'pharmacy'     : 'Medical',
    'diagnostic'   : 'Medical',
    'lab'          : 'Medical',
    // Food / Dining
    'swiggy'       : 'Food',
    'zomato'       : 'Food',
    'udipi'        : 'Food',
    'udupi'        : 'Food',
    'dominos'      : 'Food',
    'pizza hut'    : 'Food',
    'mcdonald'     : 'Food',
    'kfc'          : 'Food',
    'subway'       : 'Food',
    'burger king'  : 'Food',
    'starbucks'    : 'Food',
    'cafe coffee'  : 'Food',
    'haldiram'     : 'Food',
    'barbeque'     : 'Food',
    'hotel'        : 'Food',
    'restaurant'   : 'Food',
    'dhaba'        : 'Food',
    'biryani'      : 'Food',
    // Travel / Transport
    'ola'          : 'Travel',
    'uber'         : 'Travel',
    'rapido'       : 'Travel',
    'bmtc'         : 'Travel',
    'irctc'        : 'Travel',
    'indigo'       : 'Travel',
    'air india'    : 'Travel',
    'spicejet'     : 'Travel',
    'goibibo'      : 'Travel',
    'makemytrip'   : 'Travel',
    'redbus'       : 'Travel',
    'metro'        : 'Travel',
    'namma metro'  : 'Travel',
    // Bills / Utilities
    'bescom'       : 'Bills',
    'bbmp'         : 'Bills',
    'bwssb'        : 'Bills',
    'airtel'       : 'Bills',
    'jio'          : 'Bills',
    'bsnl'         : 'Bills',
    'vi '          : 'Bills',
    'vodafone'     : 'Bills',
    'electricity'  : 'Bills',
    'broadband'    : 'Bills',
    // Groceries / Supplies
    'bigbasket'    : 'Supplies',
    'blinkit'      : 'Supplies',
    'zepto'        : 'Supplies',
    'dmart'        : 'Supplies',
    'more '        : 'Supplies',
    'reliance fresh': 'Supplies',
    'spencer'      : 'Supplies',
    'nilgiris'     : 'Supplies',
    // Entertainment
    'pvr'          : 'Entertainment',
    'inox'         : 'Entertainment',
    'netflix'      : 'Entertainment',
    'hotstar'      : 'Entertainment',
    'amazon prime' : 'Entertainment',
    'spotify'      : 'Entertainment',
    'bookmyshow'   : 'Entertainment',
    'zee5'         : 'Entertainment',
    'sony liv'     : 'Entertainment',
    // Education
    'byju'         : 'Education',
    'unacademy'    : 'Education',
    'coursera'     : 'Education',
    'udemy'        : 'Education',
    'vedantu'      : 'Education',
    'school'       : 'Education',
    'college'      : 'Education',
    'university'   : 'Education',
    'tuition'      : 'Education',
    // Rent / Home
    'rent'         : 'Rent',
    'pg '          : 'Rent',
    'hostel'       : 'Rent',
    // Shopping
    'amazon'       : 'Supplies',
    'flipkart'     : 'Supplies',
    'myntra'       : 'Supplies',
    'lifestyle'    : 'Supplies',
    'max fashion'  : 'Supplies',
    'westside'     : 'Supplies',
    'nykaa'        : 'Supplies',
  };

  /// Returns the correct category by checking ALL text fields against the
  /// merchant override table. Checks merchant name first, then description/note,
  /// so "apollo" in any field always maps to Medical regardless of backend data.
  static String _resolveCategory(String merchantRaw, String backendCategory, {String extra = ''}) {
    // Check merchant name first (highest confidence)
    final m = merchantRaw.toLowerCase().trim();
    for (final entry in _merchantCategoryOverrides.entries) {
      if (m.contains(entry.key)) return entry.value;
    }
    // Also scan description / note fields for known brand names
    if (extra.isNotEmpty) {
      final e = extra.toLowerCase().trim();
      for (final entry in _merchantCategoryOverrides.entries) {
        if (e.contains(entry.key)) return entry.value;
      }
    }
    // Backend category is trusted only when no override matches.
    return backendCategory;
  }

  factory ExpenseItem.fromJson(Map<String, dynamic> j) {
    // Backend returns category in different shapes depending on the endpoint:
    // - POST /expenses response  → "category": {id, name, icon, custom}
    // - GET /recent-expenses     → may use "categoryResponse": {id, name...} or "category": "Food"
    // Try all known field names in priority order.
    String backendCategory = 'Other';

    for (final key in ['category', 'categoryResponse', 'categoryName', 'expenseCategory']) {
      final raw = j[key];
      if (raw == null) continue;
      if (raw is Map) {
        final name = (raw['name'] ?? raw['categoryName'] ?? '').toString().trim();
        if (name.isNotEmpty && name != 'null') { backendCategory = name; break; }
      } else {
        final name = raw.toString().trim();
        if (name.isNotEmpty && name != 'null' && name != 'Other') { backendCategory = name; break; }
      }
    }

    final merchant = (j['merchant'] ?? j['description'] ?? backendCategory).toString();

    // Collect extra text fields (description, note, subtitle) to widen brand matching.
    final extraText = [
      j['description']?.toString() ?? '',
      j['note']?.toString() ?? '',
      j['subtitle']?.toString() ?? '',
    ].join(' ');

    // Apply merchant-based override across all text fields.
    // e.g. Apollo → Medical, BMTC → Travel, Lifestyle → Supplies — always,
    // regardless of what category the backend stored.
    final String category = _resolveCategory(merchant, backendCategory, extra: extraText);

    return ExpenseItem(
      category: category,
      merchant: merchant,
      date: j['expenseDate'] ?? j['date'] ?? '',
      note: j['description'] ?? j['subtitle'] ?? '',
      amount: (j['amount'] ?? 0).toInt(),
      iconBg: _bgFor(category),
      iconColor: _colorFor(category),
      icon: _iconFor(category),
    );
  }


  static Color _bgFor(String cat) {
    final c = cat.toLowerCase();
    if (c.contains('food') || c.contains('restaurant') || c.contains('dining')) return const Color(0xFFFFF3E0);
    if (c.contains('travel') || c.contains('transport') || c.contains('cab'))   return const Color(0xFFE3F2FD);
    if (c.contains('health') || c.contains('medical') || c.contains('pharmacy')) return const Color(0xFFE8F5E9);
    if (c.contains('bill') || c.contains('electric') || c.contains('utility'))  return const Color(0xFFF3E5F5);
    if (c.contains('grocery') || c.contains('supplies'))                         return const Color(0xFFE0F2F1);
    if (c.contains('entertainment') || c.contains('movie'))                      return const Color(0xFFFCE4EC);
    if (c.contains('education') || c.contains('course'))                         return const Color(0xFFE8EAF6);
    if (c.contains('rent') || c.contains('home'))                                return const Color(0xFFF1F8E9);
    return const Color(0xFFF5F5F5);
  }

  static Color _colorFor(String cat) {
    final c = cat.toLowerCase();
    if (c.contains('food') || c.contains('restaurant') || c.contains('dining')) return const Color(0xFFE67E22);
    if (c.contains('travel') || c.contains('transport') || c.contains('cab'))   return const Color(0xFF2196F3);
    if (c.contains('health') || c.contains('medical') || c.contains('pharmacy')) return const Color(0xFF4CAF50);
    if (c.contains('bill') || c.contains('electric') || c.contains('utility'))  return const Color(0xFF9C27B0);
    if (c.contains('grocery') || c.contains('supplies'))                         return const Color(0xFF00897B);
    if (c.contains('entertainment') || c.contains('movie'))                      return const Color(0xFFE91E63);
    if (c.contains('education') || c.contains('course'))                         return const Color(0xFF3F51B5);
    if (c.contains('rent') || c.contains('home'))                                return const Color(0xFF689F38);
    return const Color(0xFF607D8B);
  }

  static IconData _iconFor(String cat) {
    final c = cat.toLowerCase();
    if (c.contains('food') || c.contains('restaurant') || c.contains('dining')) return Icons.fastfood_rounded;
    if (c.contains('travel') || c.contains('transport') || c.contains('cab'))   return Icons.directions_car_rounded;
    if (c.contains('health') || c.contains('medical') || c.contains('pharmacy')) return Icons.medication_rounded;
    if (c.contains('bill') || c.contains('electric') || c.contains('utility'))  return Icons.receipt_long_rounded;
    if (c.contains('grocery') || c.contains('supplies'))                         return Icons.shopping_cart_rounded;
    if (c.contains('entertainment') || c.contains('movie'))                      return Icons.movie_rounded;
    if (c.contains('education') || c.contains('course'))                         return Icons.school_rounded;
    if (c.contains('rent') || c.contains('home'))                                return Icons.home_rounded;
    return Icons.shopping_bag_rounded;
  }
}

// ─── Main Page ────────────────────────────────────────────────────────────────

class RecentExpensesPage extends StatefulWidget {
  const RecentExpensesPage({super.key});

  @override
  State<RecentExpensesPage> createState() => _RecentExpensesPageState();
}

class _RecentExpensesPageState extends State<RecentExpensesPage> {
  String _selectedFilter = 'All';
  String _selectedPeriod = 'Last 30 days';
  List<ExpenseItem> _expenses = [];
  bool _loading = true;
  String? _error;

  /// Filter chips built from real API categories
  List<String> get _filters {
    final seen = <String>{};
    final cats = <String>[];
    for (final e in _expenses) {
      if (e.category.isNotEmpty && seen.add(e.category)) cats.add(e.category);
    }
    cats.sort();
    return ['All', ...cats];
  }

  @override
  void initState() {
    super.initState();
    _loadExpenses();
  }

  Future<void> _loadExpenses() async {
    setState(() { _loading = true; _error = null; });
    try {
      final headers = await ApiConfig.authHeaders;
      final response = await http
          .get(Uri.parse(ApiConfig.recentExpenses), headers: headers)
          .timeout(const Duration(seconds: 15));

      if (response.statusCode == 200 || response.statusCode == 201) {
        _applyList(jsonDecode(response.body));
      } else if (response.statusCode == 403) {
        setState(() { _error = 'Session expired. Please log in again.'; _loading = false; });
      } else {
        await _loadFromExpenseService(headers);
      }
    } catch (_) {
      try {
        final headers = await ApiConfig.authHeaders;
        await _loadFromExpenseService(headers);
      } catch (e2) {
        setState(() { _error = 'Failed to load expenses. Pull down to retry.'; _loading = false; });
      }
    }
  }

  Future<void> _loadFromExpenseService(Map<String, String> headers) async {
    final response = await http
        .get(Uri.parse(ApiConfig.expenses), headers: headers)
        .timeout(const Duration(seconds: 15));
    if (response.statusCode == 200 || response.statusCode == 201) {
      _applyList(jsonDecode(response.body));
    } else {
      setState(() { _error = 'Error ${response.statusCode}: Could not load expenses.'; _loading = false; });
    }
  }

  void _applyList(dynamic decoded) {
    List<dynamic> list = [];
    if (decoded is List) {
      list = decoded;
    } else if (decoded is Map && decoded.containsKey('data')) {
      list = decoded['data'] as List? ?? [];
    } else if (decoded is Map && decoded.containsKey('expenses')) {
      list = decoded['expenses'] as List? ?? [];
    }

    debugPrint('====== HISTORY RAW RESPONSE ======');
    if (list.isEmpty) {
      debugPrint('List is EMPTY. Full decoded: ${jsonEncode(decoded)}');
    } else {
      debugPrint('First item: ${jsonEncode(list.first)}');
    }
    debugPrint('==================================');

    setState(() {
      _expenses = list.map((e) => ExpenseItem.fromJson(e)).toList();
      _selectedFilter = 'All';
      _loading = false;
    });
  }

  List<ExpenseItem> get _filteredExpenses {
    if (_selectedFilter == 'All') return _expenses;
    return _expenses.where((e) => e.category == _selectedFilter).toList();
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: RefreshIndicator(
            onRefresh: _loadExpenses,
            color: const Color(0xFF0B8A8A),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildTopBar(),
                _buildFilterChips(),
                const SizedBox(height: 4),
                Expanded(child: _buildExpenseList()),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 16, 16),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.chevron_left, size: 28, color: Color(0xFF1C1C1E)),
            onPressed: () => Navigator.maybePop(context),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(),
          ),
          const SizedBox(width: 4),
          const Text(
            'Recent Expenses',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: Color(0xFF0B8A8A),
              letterSpacing: -0.3,
              decoration: TextDecoration.underline,
              decorationColor: Color(0xFF0B8A8A),
              decorationThickness: 1.5,
            ),
          ),
          const Spacer(),
          GestureDetector(
            onTap: _showPeriodPicker,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFFD0CEC8), width: 0.9),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(_selectedPeriod,
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: Color(0xFF3C3C3E))),
                  const SizedBox(width: 4),
                  const Icon(Icons.keyboard_arrow_down_rounded, size: 16, color: Color(0xFF3C3C3E)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChips() {
    return Padding(
      padding: const EdgeInsets.only(left: 16, bottom: 8),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: _filters.map((label) {
            final isSelected = _selectedFilter == label;
            return GestureDetector(
              onTap: () => setState(() => _selectedFilter = label),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                margin: const EdgeInsets.only(right: 8),
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                decoration: BoxDecoration(
                  color: isSelected ? const Color(0xFF0B8A8A) : Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isSelected ? const Color(0xFF0B8A8A) : const Color(0xFFD0CEC8),
                    width: 0.9,
                  ),
                ),
                child: Text(label,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: isSelected ? Colors.white : const Color(0xFF3C3C3E),
                    )),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildExpenseList() {
    if (_loading) return const Center(child: CircularProgressIndicator(color: Color(0xFF0B8A8A)));

    if (_error != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.wifi_off_rounded, size: 48, color: Colors.grey),
            const SizedBox(height: 12),
            Text(_error!, style: const TextStyle(color: Color(0xFF8A8A8E), fontSize: 14), textAlign: TextAlign.center),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _loadExpenses,
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0B8A8A)),
              child: const Text('Retry', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      );
    }

    final items = _filteredExpenses;
    if (items.isEmpty) {
      return ListView(children: const [
        SizedBox(height: 120),
        Center(child: Text('No expenses found', style: TextStyle(color: Color(0xFF8A8A8E), fontSize: 14))),
      ]);
    }

    // ── Group by category ──────────────────────────────────────────────────
    // Build an ordered map: category → list of items (preserving insertion
    // order so the first-seen category appears at the top).
    final Map<String, List<ExpenseItem>> grouped = {};
    for (final item in items) {
      grouped.putIfAbsent(item.category, () => []).add(item);
    }

    // Flatten into a list of widgets: header + tiles per category group.
    final List<Widget> rows = [];
    grouped.forEach((category, groupItems) {
      // ── Category header ──
      final headerColor = groupItems.first.iconColor;
      final headerBg    = groupItems.first.iconBg;
      final headerIcon  = groupItems.first.icon;
      final totalAmount = groupItems.fold<int>(0, (sum, e) => sum + e.amount);

      rows.add(
        Padding(
          padding: const EdgeInsets.only(top: 16, bottom: 8),
          child: Row(
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(color: headerBg, borderRadius: BorderRadius.circular(8)),
                child: Icon(headerIcon, color: headerColor, size: 17),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  category,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: headerColor,
                    letterSpacing: -0.2,
                  ),
                ),
              ),
              Text(
                '₹ $totalAmount',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: headerColor,
                ),
              ),
            ],
          ),
        ),
      );

      // ── Tiles for this category ──
      for (final item in groupItems) {
        rows.add(_ExpenseTile(item: item));
      }
    });

    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      children: rows,
    );
  }

  void _showPeriodPicker() {
    final options = ['Last 7 days', 'Last 30 days', 'Last 3 months', 'This year'];
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Select Period', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            ...options.map((opt) => ListTile(
              title: Text(opt, style: const TextStyle(fontSize: 14)),
              trailing: opt == _selectedPeriod ? const Icon(Icons.check, color: Color(0xFF0B8A8A), size: 18) : null,
              onTap: () {
                setState(() => _selectedPeriod = opt);
                Navigator.pop(context);
                _loadExpenses();
              },
            )),
          ],
        ),
      ),
    );
  }
}

// ─── Expense Tile ─────────────────────────────────────────────────────────────

class _ExpenseTile extends StatelessWidget {
  final ExpenseItem item;
  const _ExpenseTile({required this.item});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFEEEAE2), width: 0.8),
      ),
      child: Row(
        children: [
          // Category-based icon
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(color: item.iconBg, borderRadius: BorderRadius.circular(12)),
            child: Icon(item.icon, color: item.iconColor, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Merchant name — primary bold text
                Text(
                  item.merchant,
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: Color(0xFF1C1C1E)),
                ),
                const SizedBox(height: 5),
                // Category pill + date
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: item.iconBg,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        item.category,
                        style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: item.iconColor),
                      ),
                    ),
                    if (item.date.isNotEmpty) ...[
                      const SizedBox(width: 8),
                      Text(
                        item.date,
                        style: const TextStyle(fontSize: 12, color: Color(0xFF8A8A8E)),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            '- ₹ ${item.amount}',
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Color(0xFFB85C1A)),
          ),
        ],
      ),
    );
  }
}