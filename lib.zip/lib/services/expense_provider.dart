// ─────────────────────────────────────────────────────────────────────────────
// lib/services/expense_provider.dart
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'dashboard_service.dart';

// ─── A single expense entry ───────────────────────────────────────────────────

class Expense {
  final String id;
  final String category; // real category: Food, Travel, Bills, Medical...
  final String merchant; // vendor/store name: trifecta, ola, udipi...
  final String date;
  final String note;
  final double amount;
  final String paymentMethod;

  const Expense({
    required this.id,
    required this.category,
    required this.merchant,
    required this.date,
    required this.note,
    required this.amount,
    required this.paymentMethod,
  });

  factory Expense.fromJson(Map<String, dynamic> j) {
    final cat = (j['categoryName'] ?? j['category'] ?? 'Other').toString();
    final merch = (j['merchant'] ?? j['name'] ?? j['description'] ?? cat)
        .toString();
    final date = (j['expenseDate'] ?? j['date'] ?? '').toString();
    final amt = (j['amount'] ?? 0).toDouble();
    final pay = (j['paymentMethod'] ?? 'UPI').toString();
    final note = (j['note'] ?? j['subtitle'] ?? '').toString();
    final id = (j['id'] ?? j['expenseId'] ?? UniqueKey().toString()).toString();

    return Expense(
      id: id,
      category: cat,
      merchant: merch,
      date: date,
      note: note,
      amount: amt,
      paymentMethod: pay,
    );
  }

  IconData get icon {
    switch (category.toLowerCase()) {
      case 'food':
        return Icons.fastfood;
      case 'travel':
        return Icons.directions_car;
      case 'bills':
        return Icons.receipt_long;
      case 'medical':
        return Icons.local_pharmacy;
      case 'entertainment':
        return Icons.movie;
      case 'education':
        return Icons.school;
      case 'supplies':
        return Icons.shopping_bag;
      case 'rent':
        return Icons.home;
      default:
        return Icons.shopping_bag;
    }
  }

  Color get color {
    switch (category.toLowerCase()) {
      case 'food':
        return const Color(0xFFFF6B6B);
      case 'travel':
        return const Color(0xFF4FC3F7);
      case 'bills':
        return const Color(0xFFFFB347);
      case 'medical':
        return const Color(0xFF81C784);
      case 'entertainment':
        return const Color(0xFFCE93D8);
      case 'education':
        return const Color(0xFF4DB6AC);
      case 'supplies':
        return const Color(0xFFA5D6A7);
      case 'rent':
        return const Color(0xFFFFD54F);
      default:
        return const Color(0xFFA5D6A7);
    }
  }

  DateTime? get parsedDate {
    try {
      return DateTime.parse(date);
    } catch (_) {
      return null;
    }
  }
}

// ─── Provider ─────────────────────────────────────────────────────────────────

class ExpenseProvider extends ChangeNotifier {
  List<Expense> _expenses = [];
  double _totalBudget = 0;
  bool _loading = true;
  String? _error;

  bool get loading => _loading;
  String? get error => _error;
  double get totalBudget => _totalBudget;

  List<Expense> get allExpenses => List.unmodifiable(_expenses);

  List<Expense> get thisMonthExpenses {
    final now = DateTime.now();
    return _expenses.where((e) {
      final d = e.parsedDate;
      return d != null && d.year == now.year && d.month == now.month;
    }).toList();
  }

  double get totalSpentThisMonth =>
      thisMonthExpenses.fold(0.0, (s, e) => s + e.amount);

  Map<String, double> get categoryTotals {
    final map = <String, double>{};
    for (final e in thisMonthExpenses) {
      map[e.category] = (map[e.category] ?? 0) + e.amount;
    }
    return map;
  }

  List<MapEntry<String, double>> get sortedCategories {
    final entries = categoryTotals.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return entries;
  }

  MapEntry<String, double>? get highestCategory =>
      sortedCategories.isEmpty ? null : sortedCategories.first;

  double get dailyAverage {
    final daysElapsed = DateTime.now().day;
    if (daysElapsed == 0) return 0;
    return totalSpentThisMonth / daysElapsed;
  }

  Map<int, double> get dailySpendingMap {
    final map = <int, double>{};
    for (final e in thisMonthExpenses) {
      final d = e.parsedDate;
      if (d != null) {
        map[d.day] = (map[d.day] ?? 0) + e.amount;
      }
    }
    return map;
  }

  List<Map<String, dynamic>> get last10DaysChart {
    final today = DateTime.now();
    return List.generate(10, (i) {
      final day = today.subtract(Duration(days: 9 - i));
      final val = dailySpendingMap[day.day] ?? 0.0;
      return {'label': '${day.day}', 'value': val, 'date': day};
    });
  }

  List<Map<String, dynamic>> get monthlyTrend {
    final now = DateTime.now();
    return List.generate(5, (i) {
      final monthOffset = 4 - i;
      final target = DateTime(now.year, now.month - monthOffset, 1);
      final total = _expenses
          .where((e) {
            final d = e.parsedDate;
            return d != null &&
                d.year == target.year &&
                d.month == target.month;
          })
          .fold(0.0, (s, e) => s + e.amount);

      const shortNames = [
        'Jan',
        'Feb',
        'Mar',
        'Apr',
        'May',
        'Jun',
        'Jul',
        'Aug',
        'Sep',
        'Oct',
        'Nov',
        'Dec',
      ];
      const longNames = [
        'JAN',
        'FEB',
        'MAR',
        'APR',
        'MAY',
        'JUN',
        'JUL',
        'AUG',
        'SEP',
        'OCT',
        'NOV',
        'DEC',
      ];

      return {
        'month': longNames[target.month - 1],
        'shortMonth': shortNames[target.month - 1],
        'amount': total,
        'year': target.year,
        'monthNum': target.month,
      };
    });
  }

  double get thisWeekTotal {
    final now = DateTime.now();
    final start = now.subtract(Duration(days: now.weekday - 1));
    return _expenses
        .where((e) {
          final d = e.parsedDate;
          return d != null &&
              !d.isBefore(DateTime(start.year, start.month, start.day));
        })
        .fold(0.0, (s, e) => s + e.amount);
  }

  List<Map<String, dynamic>> get insightItems {
    return sortedCategories.map((entry) {
      final dummy = Expense(
        id: '',
        category: entry.key,
        merchant: '',
        date: '',
        note: '',
        amount: 0,
        paymentMethod: '',
      );
      return {
        'label': entry.key,
        'amount': entry.value.toInt(),
        'color': dummy.color,
      };
    }).toList();
  }

  List<Expense> get recentExpenses {
    final sorted = List<Expense>.from(_expenses)
      ..sort((a, b) {
        final da = a.parsedDate ?? DateTime(2000);
        final db = b.parsedDate ?? DateTime(2000);
        return db.compareTo(da);
      });
    return sorted.take(10).toList();
  }

  Future<void> loadAll() async {
    _loading = true;
    _error = null;
    notifyListeners();

    try {
      final data = await DashboardService.fetchAll();

      // ✅ FIX: merchant = e.merchant (store name), NOT e.category
      _expenses = data.recentExpenses
          .map(
            (e) => Expense(
              id: UniqueKey().toString(),
              category: e.category, // Food, Travel, Bills...
              merchant: e.merchant, // trifecta, ola, udipi...
              date: e.date.isNotEmpty ? e.date : _todayIso(),
              note: e.subtitle,
              amount: e.amount.toDouble(),
              paymentMethod: 'UPI',
            ),
          )
          .toList();

      _totalBudget = data.budget.totalBudget;
    } catch (e) {
      _error = e.toString();
      debugPrint('ExpenseProvider.loadAll error: $e');
    }

    _loading = false;
    notifyListeners();
  }

  void addExpense({
    required String category,
    required String merchant,
    required String date,
    required String note,
    required double amount,
    required String paymentMethod,
  }) {
    _expenses.insert(
      0,
      Expense(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        category: category,
        merchant: merchant,
        date: date.isNotEmpty ? date : _todayIso(),
        note: note,
        amount: amount,
        paymentMethod: paymentMethod,
      ),
    );
    notifyListeners();
  }

  Future<void> refresh() => loadAll();

  static String _todayIso() {
    final now = DateTime.now();
    return '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
  }
}
